# Reverse-shell-GUI


This tool is like netcat but its a gui that's made by me  and provide an easy reverse shell remotely 
it is totally fud 
please do not uplaod to virus total.

in the vbs file put the attacker ip adress followed the 4444 try to bind it with a pdf and send to victim .
u will get a good reverse shell.

Special thanks Jabali double zero b.
